# jarvis-welcome 
#### Beautify your Termux App With a warm welcome

## [+] Installation & Usage
```
apt update
apt install git -y
pkg install mpv -y
git clone https://github.com/AmshenShanu07/jarvis-welcome.git
cd jarvis-welcome
chmod +x *
sh install.sh
exit
```
### or use Single Command
```
apt update && apt install git -y && pkg install mpv && git clone  https://github.com/AmshenShanu07/jarvis-welcome.git && cd jarvis-welcome && chmod +x * && ./install.sh
```
## [+]How to remove 
```
cd jarvis-welcome

bash rvt.sh
```
# thanks to https://github.com/htr-tech 
 # For providing the code

    
## [+] Find Me on :
#### Telegram :https://t.me/AmshenShanu
#### Plzz text your errors to this grp :https://t.me/joinchat/NM1A0FN8Bu-swiQNFRhdgw

