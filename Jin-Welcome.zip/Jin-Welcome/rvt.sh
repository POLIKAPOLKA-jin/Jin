pip install bs4
cd
cd ..
cd usr/etc
rm bash.bashrc
cd $HOME/Jin-Welcome/Revert
mv bash.bashrc $PREFIC/etc
python $HOME/Jin-Welcome/Revert/Thanks.py
